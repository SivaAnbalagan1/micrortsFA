IMPORTANT! 

Files  maql-player-example.xml and maql-rival-example.xml are associated with 
PersistentMultiAgentQLearningTest.

Don't change the files without changing the test!
