package rl.models.aggregate;

public enum Aggregate {
	FEW,
	FAIR,
	MANY
}
